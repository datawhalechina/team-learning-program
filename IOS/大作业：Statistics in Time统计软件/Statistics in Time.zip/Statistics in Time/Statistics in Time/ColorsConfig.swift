//
//  ColorsConfig.swift
//  Statistics in Time
//
//  Created by mac on 2021/10/29.
//

import UIKit

struct ColorsConfig {
    static let selectedText = UIColor.white
    static let text = UIColor.black
    static let textDisabled = UIColor.purple
    static let selectionBackground = UIColor(red: 1, green: 0.647, blue: 0, alpha: 1.0)
    static let sundayText = UIColor(red: 1.0, green: 0.2, blue: 0.2, alpha: 1.0)
    static let sundayTextDisabled = UIColor(red: 1.0, green: 0.6, blue: 0.6, alpha: 1.0)
    static let sundaySelectionBackground = sundayText
}
