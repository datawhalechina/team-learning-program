//
//  StatisticsViewController.swift
//  Statistics in Time
//
//  Created by mac on 2021/10/29.
//

import UIKit
import SigmaSwiftStatistics
import TinyConstraints

class StatisticsViewController: UIViewController,UITextFieldDelegate {
    let textField = UITextField(frame: CGRect(x: 120, y: 140, width: 180, height: 40))
    let alertLabel = UILabel(frame: CGRect(x: 20, y: 140, width: 90, height: 40))
    var resultLabel = UILabel(frame: CGRect(x: 175, y: 200, width: 200, height: 40))
    var averLabel = UILabel(frame: CGRect(x: 105, y: 200, width: 90, height: 40))
    var resultLabel2 = UILabel(frame: CGRect(x: 175, y: 240, width: 200, height: 40))
    var centralMomentLabel = UILabel(frame:CGRect(x: 105, y: 240, width: 90, height: 40))
    var resultLabel3 = UILabel(frame: CGRect(x: 175, y: 280, width: 200, height: 40))
    var variancePopulationLabel = UILabel(frame: CGRect(x: 105, y: 280, width: 90, height: 40))
    var resultLabel4 = UILabel(frame:CGRect(x: 175, y: 320, width: 200, height: 40))
    var coefficientOfVariationLabel = UILabel(frame: CGRect(x: 95, y: 320, width: 90, height: 40))
    var resultLabel5 = UILabel(frame:CGRect(x: 175, y: 360, width: 200, height: 40))
    var kurtosisA = UILabel(frame: CGRect(x: 105, y: 360, width: 90, height: 40))
    var resultLabel6 = UILabel(frame:CGRect(x: 175, y: 400, width: 200, height: 40))
    var kurtosisB = UILabel(frame: CGRect(x: 105, y: 400, width: 90, height: 40))
    var resultLabel7 = UILabel(frame:CGRect(x: 175, y: 440, width: 200, height: 40))
    var skewnessLabel = UILabel(frame: CGRect(x: 105, y: 440, width: 90, height: 40))
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        textField.resignFirstResponder()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textField.borderStyle = .roundedRect
        textField.textColor = UIColor.black
        alertLabel.text = "数据输入："
        alertLabel.textColor = UIColor.black
        resultLabel.text = " "
        resultLabel2.text = " "
        resultLabel3.text = " "
        resultLabel4.text = " "
        resultLabel5.text = " "
        resultLabel6.text = " "
        resultLabel7.text = " "
        averLabel.text = "平均值："
        centralMomentLabel.text = "标准误："
        variancePopulationLabel.text = "Var值："
        coefficientOfVariationLabel.text = "变异系数："
        kurtosisA.text = "峰度A："
        kurtosisB.text = "峰度B："
        skewnessLabel.text = "偏度："
        
        
        
        let btn:UIButton=UIButton.init(frame: CGRect(x:310,y:140, width:100,height:40))//创建按钮，并设置位置，宽度、高度
        btn.setTitle("开始统计", for: UIControl.State.normal)//设置按钮上的文字
        btn.backgroundColor = UIColor.systemBlue
        btn.addTarget(self, action:#selector(btnClick(_:)), for: UIControl.Event.touchDown)//为按钮添加touchDown事件(按下)
        self.view.addSubview(btn)//将标签添加到View中
        self.view.addSubview(textField)
        self.view.addSubview(alertLabel)
        self.view.addSubview(resultLabel)
        self.view.addSubview(averLabel)
        self.view.addSubview(centralMomentLabel)
        self.view.addSubview(resultLabel2)
        self.view.addSubview(variancePopulationLabel)
        self.view.addSubview(resultLabel3)
        self.view.addSubview(coefficientOfVariationLabel)
        self.view.addSubview(resultLabel4)
        self.view.addSubview(resultLabel5)
        self.view.addSubview(resultLabel6)
        self.view.addSubview(kurtosisA)
        self.view.addSubview(kurtosisB)
        self.view.addSubview(resultLabel7)
        self.view.addSubview(skewnessLabel)
        //textField.delegate = self
    }
    
    
    @objc func btnClick(_:  Any){
        let inputNumber:String = String(textField.text!)
        let fullNumberArr = inputNumber.split{$0 == " "}.map(String.init)
        let arr = changeArray(textArray: fullNumberArr)
        print(Sigma.average(arr) ?? 0)
        resultLabel.text = String(Sigma.average(arr) ?? 0)
        resultLabel2.text = String(Sigma.standardErrorOfTheMean(arr) ?? 0)
        resultLabel3.text = String(Sigma.varianceSample(arr) ?? 0)
        resultLabel4.text = String(Sigma.coefficientOfVariationSample(arr) ?? 0)
        resultLabel5.text = String(Sigma.kurtosisA(arr) ?? 0)
        resultLabel6.text = String(Sigma.kurtosisB(arr) ?? 0)
        resultLabel7.text = String(Sigma.skewnessA(arr) ?? 0)
    }
    
    func changeArray(textArray: [String]) -> [Double] {
        textArray.compactMap { Double($0) }
    }
}
