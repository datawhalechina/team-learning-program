//
//  MainViewController.swift
//  Statistics in Time
//
//  Created by mac on 2021/10/29.
//

import UIKit

class MainViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBar.tintColor = UIColor(red: 0/255, green:169/255, blue:169/255, alpha:1)
        addNormalTabbar()
    }
    
    func addNormalTabbar() {
        //初始化
        let updateVc = StatisticsViewController.init()
        updateVc.view.backgroundColor = UIColor.red
        setupOneChildViewController(title: "统计", image: "Trends", seletedImage: "TrendsFilled", controller: StatisticsViewController.init())
        setupOneChildViewController(title: "概要", image: "Settings", seletedImage: "SettingsFilled", controller: ProfileViewController.init())
    }
    fileprivate func  setupOneChildViewController(title: String,image: String,seletedImage: String,controller: UIViewController){
        controller.tabBarItem.title = title
        controller.title = title
        //这里设置背景色 是每一个vc设置的都一样
        controller.view.backgroundColor = UIColor.white
        controller.tabBarItem.image = UIImage.init(named: image)
        controller.tabBarItem.selectedImage = UIImage.init(named: seletedImage)
        let naviController = navigationViewController.init(rootViewController: controller)
        addChild(naviController)
    }
}
